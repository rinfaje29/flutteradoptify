class AdoptionPolicyModel {
  final String title;
  final String description;

  AdoptionPolicyModel({required this.title, required this.description});
}
